<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $loggedInUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logged): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="container grey-text text-darken-2 mb-0">
        <div class="row">
            <div class="col-md-10 offset-md-1 mb-0">
                <div class="section scrollspy" id="feedback-step">
                    <div class="row">
                        <div class="text-center col-md-12">
                            <h5 style="font-size: 20px; font-weight: 100">Nomination Form</h5>
                            <img src="<?php echo e(asset('img/itsu.jpeg')); ?>" class="img-fluid responsive-img text-center" height="auto" width="80">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-sm-4">
                            <div class="row">
                                <div class="col-md-4  text-right">
                                    <h5><?php echo e($logged->voting->name); ?></h5>
                                </div>
                                <div class="col-md-4 text-right">
                                    <h5 class="float-right"><?php echo e($logged->department->name); ?></h5>
                                </div>
                                <div class="col-md-4 text-right">
                                    <a class="btn btn-dark btn-sm m-0 float-right"  href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <i class="ti ti-power-off"> </i>Logout
                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </div>
                            <?php echo $__env->make('layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <div class="card">
                                <div class="card-content">
                                    <form action="<?php echo e(route('home.store')); ?>" enctype="multipart/form-data" method="post">
                                        <?php echo csrf_field(); ?>
                                        <ul class="stepper horizontal" id="feedbacker">
                                            <li class="step active">
                                                <div data-step-label="Upload Profile Photo" class="step-title waves-effect waves-dark">
                                                    Profile Photo
                                                </div>
                                                <div class="step-content">
                                                    <div class="picture-container">
                                                        <div class="picture">
                                                            <img src="<?php echo e(asset('img/profiledefault.png')); ?>" class="picture-src" id="wizardPicturePreview" title="" />
                                                            <input type="file" class="validate" name="image_file" required  id="wizard-picture">
                                                        </div>
                                                        <h6>Choose Picture</h6>

                                                        <small class="text-danger">
                                                            Dimension - 640 x 640 pixels<br>
                                                            Max Size - 2MB
                                                        </small>
                                                    </div>
                                                    <div class="step-actions float-right">
                                                        <button class="waves-effect waves-dark btn blue next-step" data-feedback="someFunction">Next</button>
                                                    </div>
                                                </div>
                                            </li>

                                            <li class="step">
                                                <div data-step-label="Tell us about you" class="step-title waves-effect waves-dark">
                                                    Personal Info.
                                                </div>
                                                <div class="step-content">

                                                    <div class="row input-field">
                                                        <div class=" col-md-5 offset-md-1">
                                                            <input id="first_name" name="first_name" class="validate" value="<?php echo e(old('first_name')); ?>" type="text"  required>
                                                            <label for="first_name">First Name</label>
                                                        </div>
                                                        <div class="col-md-5">
                                                            <label for="last_name">Last Name</label>
                                                            <input id="last_name" name="last_name" class="validate" value="<?php echo e(old('last_name')); ?>"  type="text" required>
                                                        </div>
                                                    </div>

                                                    <div class="form-group row input-field">
                                                        <div class="col-md-5 offset-md-1">
                                                            <label for="other_name">Other Name</label>
                                                            <input id="other_name" name="other_name" value="<?php echo e(old('other_name')); ?>" type="text" class="validate" >
                                                        </div>
                                                        <div class="col-md-5">
                                                            <label for="dateOfBirth">Date of Birth</label><br>
                                                            <input name="dateOfBirth" id="dateOfBirth" value="<?php echo e(old('dateOfBirth')); ?>" required type="date" class="validate">
                                                        </div>
                                                    </div>

                                                    <div class="step-actions float-right">
                                                        <button class="waves-effect waves-dark btn blue next-step">Next</button>
                                                        <button class="waves-effect waves-dark btn-flat previous-step">Previous</button>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="step">
                                                <div class="step-title waves-effect waves-dark">
                                                    Contact Details
                                                </div>
                                                <div class="step-content">

                                                    <div class="row ">
                                                        <div class="input-field col-md-5 offset-md-1">
                                                            <label for="home_town">Home Town</label>
                                                            <input id="home_town" type="text" value="<?php echo e(old('home_town')); ?>" name="home_town" required class="validate">
                                                        </div>
                                                        <div class="col-md-5">
                                                            <label for="region">Region</label>
                                                            <select name="region" class="form-control" required id="region">
                                                                <option value=""> Select </option>
                                                                <option value="Greater Accra">Greater Accra</option>
                                                                <option value="Central">Central</option>
                                                                <option value="Eastern">Eastern</option>
                                                                <option value="Ashanti">Ashanti</option>
                                                                <option value="Northern">Northern</option>
                                                                <option value="Upper West">Upper West</option>
                                                                <option value="Upper East">Upper East</option>
                                                                <option value="Western">Western</option>
                                                                <option value="Volta">Volta</option>
                                                                <option value="Brong Ahafo">Brong Ahafo</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="row input-field">
                                                        <div class="col-md-5 offset-md-1">
                                                            <label for="home_address">Home Address</label>
                                                            <input id="home_address" type="text" value="<?php echo e(old('home_address')); ?>" name="home_address" class="validate" required>
                                                        </div>
                                                        <div class="col-md-5">
                                                            <label id="phone-mask">Phone Number</label>
                                                            <input type="tel" value="<?php echo e(old('telephone')); ?>" name="telephone" class="validate phone-inputmask" required id="phone-mask" >
                                                        </div>
                                                    </div>
                                                    <div class="row input-field">
                                                        <div class="col-md-10 offset-md-1">
                                                            <label for="email">Email</label>
                                                            <input type="email" id="email" value="<?php echo e(old('email')); ?>" name="email" class="validate" required>
                                                        </div>
                                                    </div>
                                                    <div class="step-actions">
                                                        <button class="waves-effect waves-dark btn blue next-step">Next</button>
                                                        <button class="waves-effect waves-dark btn-flat previous-step">Previous</button>
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="step">
                                                <div class="step-title waves-effect waves-dark">
                                                    Academics
                                                </div>
                                                <div class="step-content">
                                                    <div class="row ">
                                                        <div class="col-md-3 offset-md-1">
                                                            <label for="levels">Level</label><br>
                                                            <select id="levels" name="levels" required class="form-control">
                                                                <option value=""> Select </option>
                                                                <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($level->id); ?>"><?php echo e($level->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-sm-3 input-field">
                                                            <div class="form-group">
                                                                <label for="index_number">Index Number</label><br>
                                                                <input type="text" id="index_number" name="index_number" disabled value="<?php echo e(Auth::User()->name); ?>" required class="validate">
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-3">
                                                            <div class="form-group">
                                                                <label for="cgpa">CGPA</label>
                                                                <input type="text" value="<?php echo e(old('cgpa')); ?>" id="cgpa" class="validate cgpa"  name="cgpa" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-5 offset-md-1">
                                                            <label for="position">Position</label><br>
                                                            <select  name="position" required id="position" class="form-control">
                                                                <option value=""> Select </option>
                                                                <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option value="<?php echo e($position->id.' '.$position->position_number); ?>"><?php echo e($position->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-md-5 input-field">
                                                            <div class="form-group">
                                                                <label for="previous_position">Previous Position Held</label>
                                                                <input id="previous_position" type="text" class="form-control" value="<?php echo e(old('previous_position')); ?>" name="previous_position">
                                                                <small class="text-danger">Leave it blank if you don't have!</small>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="step-actions">
                                                        <button class="waves-effect waves-dark btn blue" type="submit">Finish</button>
                                                        <button class="waves-effect waves-dark btn-flat previous-step">Previous</button>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>